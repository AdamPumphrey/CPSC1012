﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/*
Purpose: Demonstrate beginner understanding of Visual Studio, writing text to console in C#
Author: Adam Pumphrey
Date Modified: Sept. 11, 2020
*/
namespace CPSC1012_Exercise01_AdamPumphrey
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello Allan, my name is Adam Pumphrey and I am in the Systems Administration DMIT concentration");
            Console.WriteLine();
            Console.WriteLine("I enjoy sports and I am a huge Oilers fan.");
            Console.WriteLine();
            Console.WriteLine("I graduated from the University of Alberta with a degree in Computing Science " +
                "last semester, so I am hoping to do well in the course and have some fun.");

            Console.ReadLine();
        }
    }
}
